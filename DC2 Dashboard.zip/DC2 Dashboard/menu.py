from dash import dcc
from dash import html



from DC2_APP.data import *

df = extract_street_for_district(district)
tab1_list1 = df_seasonality["Crime type"].unique()
tab3_list1 = df['LSOA code'].unique()
tab3_list2 = df['Crime type'].unique()
tab3_list3 = df['Month'].unique()


# ['November-2021', 'December-2021', 'January-2022', 'February-2022', 'March-2022', 'April-2022',
# 'May-2022', 'June-2022', 'July-2022', 'August-2022', 'September-2022', 'October-2022']

def generate_control_tab1():
    """

    :return: A Div containing controls for graphs.
    """
    return html.Div(
        id="control-card",
        children=[
            html.Label('Select Crime Type:'),
            dcc.Dropdown(
                id="task1_plot",
                options=[{"label": i, "value": i} for i in tab1_list1],
                value=tab1_list1[0],
            ),
        ], style={"textAlign": "float-left"}
    )


def generate_control_tab3():
    """

    :return: A Div containing controls for graphs.
    """
    return html.Div(
        id="control-card",
        children=[
            html.Label('Select a LSOA in your District:'),
            dcc.Dropdown(
                id="task2_plot",
                options=[{"label": i, "value": i} for i in tab3_list1],
                value=tab3_list1[0],
            ),
            html.Br(),
            html.Label('Select Crime Type:'),
            dcc.Dropdown(
                id="task3_plot",
                options=[{"label": i, "value": i} for i in tab3_list2],
                value=tab3_list2[0],
            ),
            html.Br(),
            html.Label('Select Prediction Time:'),
            dcc.Dropdown(
                id="task4_plot",
                options=[{"label": i, "value": i} for i in tab3_list3],
                value=tab3_list3[0],
            ),
        ], style={"textAlign": "float-left"}
    )
