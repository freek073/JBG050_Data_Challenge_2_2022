tab_style = {
    'backgroundColor': '#FFFFFF',
    'border': '3px solid #6B7E8D',
    'fontWeight': 'bold',
    'border-right': 'none'

}

tab_selected_style = {
    'backgroundColor': '#FFFFFF',
    'border': '3px solid #6B7E8D',
    'border-right': 'none',
    'fontWeight': 'bold',
    'color': '#135DD8',
}