from plotly.subplots import make_subplots
import plotly.graph_objects as go
from DC2_APP.data import *
from model_sas import *
import plotly.express as px
import folium
# folium installation problem solved with: conda config --append channels conda-forge

from folium import plugins
from folium.plugins import MarkerCluster
from sklearn.cluster import KMeans

import os

path_local = os.getcwd()
path_parent = os.path.abspath(os.path.join(path_local, os.pardir))

if district == 'Gwent':
    start_loc = [51.789, -3.018]
elif district == 'London':
    start_loc = [51.519876, -0.108284]

def kmeans_markers(df):
    number_of_markers = int(round(len(df) / 1000, 0))
    kmeans = KMeans(n_clusters=number_of_markers, max_iter=1000, init='k-means++')
    lat_long = df[['Latitude', 'Longitude']]
    kmeans.fit(lat_long)  # Compute k-means clustering.
    df_clusetrs = df.copy()
    df_clusetrs['cluster_label'] = kmeans.predict(lat_long)
    centers = kmeans.cluster_centers_  # Coordinates of cluster centers.
    # labels = df_clusetrs['cluster_label']  # Labels of each point
    return centers


def allocation_marker(df, m):
    for coord in kmeans_markers(df):
        c_lat, c_long = coord
        folium.CircleMarker([c_lat, c_long],
                            radius=10,
                            popup="Cops Allocation",
                            color='black',
                            fill_color="#3db7e4",  # divvy color
                            ).add_to(m)


def FoliumMap(df, input1, input2):
    m = folium.Map([input1, input2], zoom_start=10)
    for index, row in tq.tqdm(df.iterrows()):
        folium.CircleMarker([row['Latitude'], row['Longitude']],
                            radius=0.05,
                            fill_color="black",  # divvy color
                            opacity=0.05
                            ).add_to(m)

    dfmatrix = df[['Latitude', 'Longitude']].values
    m.add_child(plugins.HeatMap(dfmatrix, radius=15))

    latitude = []
    longitude = []
    m1 = folium.Map(start_loc, zoom_start=10)
    for index, row in df.iterrows():
        latitude.append(row["Latitude"])
        longitude.append(row["Longitude"])

    # c_lat = sum(latitude) / len(latitude)
    # c_long = sum(longitude) / len(longitude)
    # c_lat_1, c_long_1 = kmeans_markers(df)[0]
    # c_lat_2, c_long_2 = kmeans_markers(df)[0]
    # c_lat_3, c_long_3 = kmeans_markers(df)[0]
    #
    # folium.CircleMarker([c_lat_2, c_long_2],
    #                     radius=10,
    #                     popup="Cops Allocation",
    #                     color='black',
    #                     fill_color="#3db7e4",  # divvy color
    #                     ).add_to(m)

    allocation_marker(df, m)

    return m


df_map = df_future_dt.rename(columns={'Long_pred': 'Longitude', 'Lat_pred': 'Latitude'})
current_map = FoliumMap(df_map, start_loc[0], start_loc[1])
current_map.save('current_map.html')


def plot_seasonality(value):
    df_plot = df_seasonality[df_seasonality['Crime type'] == value]
    fig_seasonality = px.line(df_plot, x="Month", y='yearly',
                              title='<b>Monthly Seasonality Patterns for ' + value.title() + '<b>',
                              labels={'yearly': 'Seasonality Index', 'Month': 'Monthly Index'})
    fig_seasonality.update_layout(xaxis=dict(
        tickmode='array',
        tickvals=['2015-01-01', '2015-03-01', '2015-05-01', '2015-07-01', '2015-09-01', '2015-11-01'],
        ticktext=['January', 'March', 'May', 'July', 'September', 'November']
    ), title_x=0.5, title_font_color="#135DD8")
    return fig_seasonality


df = extract_street_for_district(district)
df_sum = df.groupby(['Month']).count().reset_index().rename(columns={'LSOA code': 'count'})
si = pd.read_csv(path_parent + '/files/si.csv')
df_sum_month = df_sum['Month'].to_list()
df_sum_crime = df_sum['count'].to_list()
si_month = si['Month'].to_list()
si_si = si['stringency_index'].to_list()
fig_sumcrimes = make_subplots(rows=2, cols=1, shared_xaxes=True, row_heights=[1, 0.4], vertical_spacing=0.05)
fig_sumcrimes.append_trace(go.Scatter(x=df_sum_month, y=df_sum_crime), row=1, col=1)
fig_sumcrimes.append_trace(go.Scatter(x=si_month, y=si_si), row=2, col=1)
fig_sumcrimes.update_yaxes(title_text="Number of Crimes", row=1, col=1)
fig_sumcrimes.update_yaxes(title_text="SI", showgrid=False, showticklabels=False, row=2, col=1)
fig_sumcrimes.update_xaxes(title_text="Yearly Change", showgrid=False, row=2, col=1)
fig_sumcrimes.update_layout(showlegend=False, title_text="<b> Number of Crimes Shown per Year VS "
                                                         "Stringency "
                                                         "Index </b>", title_x=0.5, title_font_color="#135DD8")

df_crt = df.groupby(['Crime type', 'Month']).count().reset_index().rename(columns={'LSOA code': 'count'})
fig_crimetype = px.line(df_crt, x='Month', y='count', color='Crime type', title='<b> Number of Crimes Shown per Crime '
                                                                                'Type per Year </b>',
                        labels={'count': 'Number of Crimes', 'Month': 'Yearly Change'})
fig_crimetype.update_layout(title_x=0.5, title_font_color="#135DD8")


def line_plot(final_pred1):
    x = final_pred1['Month'].tolist()
    y = final_pred1['prediction'].tolist()
    y_upper = final_pred1['max'].tolist()
    y_lower = final_pred1['min'].tolist()

    fig = go.Figure([
        go.Scatter(
            x=x,
            y=y,
            line=dict(color='#135DD8'),
            mode='lines'
        ),
        go.Scatter(
            x=x + x[::-1],  # x, then x reversed
            y=y_upper + y_lower[::-1],  # upper, then lower reversed
            fill='toself',
            fillcolor='rgba(0, 191, 255, 0.2)',
            line=dict(color='rgba(255,255,255,0)'),
            hoverinfo="skip",
            showlegend=False
        )
    ])
    fig.update_layout(showlegend=False, title_text="<b>Predicted Crimes per Month with Variances </b>", title_x=0.5, title_font_color="#135DD8")
    fig.update_yaxes(title_text="Predicted Crimes")
    fig.update_xaxes(title_text="Month")

    return fig
