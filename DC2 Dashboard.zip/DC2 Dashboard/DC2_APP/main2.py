import base64
import json
import dash
import os
from dash import dcc
from dash import html
from dash import Dash
from dash import dash_table
from style import *
from menu import *
from DC2_APP.data import *
from plots import *

from dash.dependencies import Input, Output

path_local = os.getcwd()
path_parent = os.path.abspath(os.path.join(path_local, os.pardir))

app = Dash(__name__)
app.title = "Group 12 Dashboard"

name = html.Strong(district.upper())
image_filename = 'fig-for-dashboard.png'

app.layout = html.Div([
    html.Img(src=app.get_asset_url(image_filename), height='100px', width='170px',
             style={'float': 'left', 'display': 'inline', "padding-top": "1.8%"}),
    html.Img(src=app.get_asset_url(image_filename), height='100px', width='170px',
             style={'float': 'right', 'display': 'inline', "padding-top": "1.8%"}),
    html.H1('RESOURCE ALLOCATION - 2022 PREDICTIONS',
            style={'textAlign': 'left', 'color': '#6B7E8D', 'fontSize': 24, "font-weight": "545"
                , "padding-left": "-3%", 'margin-top': "5%"}),
    html.H2(children=[name, " POLICE"],
            style={'textAlign': 'center', 'color': '#135DD8', 'fontSize': 80, 'margin-top': "0px",
                   'margin-bottom': "15px"}),
    dcc.Tabs(id='tabs-example', value='tab-1', children=[

        dcc.Tab(label='DEMAND FORECASTING MODEL', value='tab-1', style=tab_style, selected_style=tab_selected_style),
        dcc.Tab(label='INTERACTIVE MAP', value='tab-2', style=tab_style,
                selected_style=tab_selected_style),
        dcc.Tab(label='ADDITIONAL INSIGHTS', value='tab-3', style=tab_style,
                selected_style=tab_selected_style),

    ]),
    html.Div(id='tabs-example-content-1')
])

df = df_predictions
uk_msoas = json.load(open(path_parent + "/files/msoa.geojson", "r"))

uk_msoas_filtered = {"type": "FeatureCollection",
                     "name": "Middle_Layer_Super_Output_Areas__December_2011__Boundaries_Full_Clipped__BFC__EW_V3",
                     "crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
                     'features' : []}

for x in range(len(uk_msoas['features'])):
    if uk_msoas['features'][x]['properties']['MSOA11CD'] in [y for y in df['MSOA code'].unique()]:
        uk_msoas_filtered['features'].append({"type": uk_msoas['features'][x]['type'],
                                              "properties" : uk_msoas['features'][x]['properties'],
                                             "geometry" : uk_msoas['features'][x]['geometry']})



@app.callback(
    dash.dependencies.Output('tabs-example-content-1', 'children'),
    dash.dependencies.Input('tabs-example', 'value')
)
def render_content(tab):
    if tab == 'tab-1':
        return html.Div(
            id="app-container",
            children=[
                html.Br(),
                html.H3(html.Strong("DataFrame"),
                        style={'textAlign': 'center', 'color': '#135DD8', 'fontSize': '40', 'margin-bottom': '-3rem'}),
                html.Br(),
                html.Div(
                    id="dataframe-style",
                    className="dataframe-style",
                    children=[
                        dash_table.DataTable(
                            id='dataframe',
                            columns=[
                                {'id': 'Month', 'name': 'Month'},
                                {'id': 'MSOA code', 'name': 'MSOA Code'},
                                {'id': 'Crime type', 'name': 'Crime Type'},
                                {'id': 'prediction', 'name': 'Predicted Crime'},
                                {'id': 'change', 'name': 'Percentage Change from Previous Year'},
                            ],
                            data=df.to_dict('records'),
                            filter_action="native",
                            sort_action="native",
                            sort_mode="multi",
                            page_action="native",
                            page_current=0,
                            page_size=10,
                            export_format='csv',
                            export_headers='display',
                            merge_duplicate_headers=True,
                            style_table={'overflowX': 'scroll',
                                         'height': '100%', 'width': '80%',
                                         'padding-left': '10%', 'padding-right': '10%'},
                            style_header={'backgroundColor': '#FFFFFF', 'border': '2px solid #6B7E8D'},
                            style_cell={'backgroundColor': '#FFFFFF',
                                        'color': '#6B7E8D', 'textAlign': 'center', 'border': '2px solid #6B7E8D'},
                            sort_by=[]),
                    ]),
                html.Div(id='dataframe-vis')
            ])

    elif tab == 'tab-2':
        return html.Div(
            id="app-container",
            children=[
                html.H3("Stop & Search Prime Policing Allocation", style={'textAlign': 'center', 'color': '#135DD8',
                                                                          'fontSize': '30', 'fontWeight': 'bold',
                                                                          'margin-top': '3rem'}),
                html.H5('This map shows predicted locations of stop and search incidents, based on their historical locations.',
                        style={'textAlign': 'center', 'color': '#6B7E8D', 'fontSize': '10', 'margin-top': '-2rem',
                               'margin-bottom': '3rem'}),
                html.Div(
                    id="interactive-map",
                    className="interactive-map",
                    children=[
                        html.Iframe(id='map', srcDoc=open('current_map.html').read(), width='100%', height='700')
                    ]),
            ])

    elif tab == 'tab-3':
        return html.Div(
            id="app-container",
            children=[
                # Left column
                html.Div(
                    id="left-column",
                    className="three columns",
                    children=generate_control_tab1()
                ),

                html.Div(
                    id="right-column",
                    className="nine columns",
                    children=[
                        dcc.Graph(id='graph1'),
                        dcc.Graph(id='graph2', figure=fig_sumcrimes),
                        dcc.Graph(id='graph3', figure=fig_crimetype),
                    ])
            ])


@app.callback(
    dash.dependencies.Output('graph1', 'figure'),
    [dash.dependencies.Input(component_id='task1_plot', component_property='value')]
)
def build_fig1(value):
    return plot_seasonality(value)


@app.callback(
    Output('dataframe-vis', "children"),
    Input('dataframe', "derived_virtual_data"),
    Input('dataframe', "derived_virtual_selected_rows"))
def update_graphs(rows, derived_virtual_selected_rows):
    if derived_virtual_selected_rows is None:
        derived_virtual_selected_rows = []

    dff = df if rows is None else pd.DataFrame(rows)

    if dff['MSOA code'].nunique() == 1 and dff['Crime type'].nunique() == 1:
        fig_line = line_plot(dff)
        return [dcc.Graph(id='graph3_tab1', figure=fig_line)]
    elif dff['Month'].nunique() == 1 and dff['Crime type'].nunique() == 1:
        fig_map = px.choropleth(dff, geojson=uk_msoas_filtered, color="change",
                            locations="MSOA code", featureidkey="properties.MSOA11CD", title='<b>Map of Predicted '
                                                                                             'Change in Crimes per '
                                                                                             'MSOA <b>',
                            color_continuous_scale=px.colors.diverging.RdBu, range_color=[-400, 400])
        fig_map.update_layout(margin={"r": 0, "t": 40, "l": 0, "b": 0}, coloraxis_colorbar=dict(title="Change (%)"),
                              title_x=0.5, title_font_color="#135DD8")

        fig_map.update_geos(fitbounds="locations", visible=False)
        return [dcc.Graph(id='graph3_tab1', figure=fig_map)]
    else:
        hist1 = px.histogram(dff, x='Crime type', y='prediction', title='<b>Predicted Amount of Crimes per Crime Type<b>',
                             labels={'prediction': 'Predicted Crimes', 'Crime type': 'Crime Type'})
        hist1.update_layout(title_x=0.5, title_font_color="#135DD8")
        hist1.update_traces(marker_color='#135DD8')
        hist2 = px.histogram(dff, x='MSOA code', y='prediction', title='<b>Predicted Amount of Crimes per MSOA <b>',
                             labels={'prediction': 'Predicted Crimes', 'MSOA code': 'MSOA Code'})
        hist2.update_layout(title_x=0.5, title_font_color="#135DD8")
        hist2.update_traces(marker_color='#135DD8')
        return [dcc.Graph(id='graph4_tab1', figure=hist1),
                dcc.Graph(id='graph5_tab1', figure=hist2)
                ]

    # colors = ['#135DD8' if i in derived_virtual_selected_rows else '#135DD8'
    #            for i in range(len(dff))]


if __name__ == "__main__":
    app.run_server(debug=False)
