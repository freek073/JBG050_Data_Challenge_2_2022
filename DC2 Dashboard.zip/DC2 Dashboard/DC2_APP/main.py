import base64

import dash
from dash import dcc
from dash import html
from dash import Dash
from dash import dash_table
from style import *
from menu import *
from DC2_APP.data import *
from plots import *

from dash.dependencies import Input, Output

app = Dash(__name__)
app.title = "Group 12 Dashboard"

name = html.Strong(district.upper())
image_filename = 'fig-for-dashboard.png'

app.layout = html.Div([
    html.Img(src=app.get_asset_url(image_filename), height='100px', width='170px',
             style={'float': 'left', 'display': 'inline', "padding-top": "1.8%"}),
    html.Img(src=app.get_asset_url(image_filename), height='100px', width='170px',
             style={'float': 'right', 'display': 'inline', "padding-top": "1.8%"}),
    html.H1('RESOURCE ALLOCATION - 2022 PREDICTIONS',
            style={'textAlign': 'left', 'color': '#6B7E8D', 'fontSize': 24, "font-weight": "545"
                , "padding-left": "-3%", 'margin-top': "5%"}),
    html.H2(children=[name, " POLICE"],
            style={'textAlign': 'center', 'color': '#135DD8', 'fontSize': 80, 'margin-top': "0px",
                   'margin-bottom': "15px"}),
    dcc.Tabs(id='tabs-example', value='tab-1', children=[

        dcc.Tab(label='DEMAND FORECASTING MODEL', value='tab-1', style=tab_style, selected_style=tab_selected_style),
        dcc.Tab(label='INTERACTIVE MAP', value='tab-2', style=tab_style,
                selected_style=tab_selected_style),
        dcc.Tab(label='ADDITIONAL INSIGHTS', value='tab-3', style=tab_style,
                selected_style=tab_selected_style),

    ]),
    html.Div(id='tabs-example-content-1')
])

df = df_predictions


@app.callback(
    dash.dependencies.Output('tabs-example-content-1', 'children'),
    dash.dependencies.Input('tabs-example', 'value')
)
def render_content(tab):
    if tab == 'tab-1':
        return html.Div(
            id="app-container",
            children=[
                html.Br(),
                html.H3(html.Strong("DataFrame"),
                        style={'textAlign': 'center', 'color': '#135DD8', 'fontSize': '40', 'margin-bottom': '-3rem'}),
                html.Br(),
                html.Div(
                    id="dataframe-style",
                    className="dataframe-style",
                    children=[
                        dash_table.DataTable(
                            id='dataframe',
                            columns=[
                                {'id': 'Month', 'name': 'Month'},
                                {'id': 'MSOA code', 'name': 'MSOA Code'},
                                {'id': 'Crime type', 'name': 'Crime Type'},
                                {'id': 'prediction', 'name': 'Predicted Crime'},
                                {'id': 'change', 'name': 'Percentage Change from Previous Year'},
                            ],
                            data=df.to_dict('records'),
                            filter_action="native",
                            sort_action="native",
                            sort_mode="multi",
                            page_action="native",
                            page_current=0,
                            page_size=10,
                            export_format='csv',
                            export_headers='display',
                            merge_duplicate_headers=True,
                            style_table={'overflowX': 'scroll',
                                         'height': '100%', 'width': '80%',
                                         'padding-left': '10%', 'padding-right': '10%'},
                            style_header={'backgroundColor': '#FFFFFF', 'border': '2px solid #6B7E8D'},
                            style_cell={'backgroundColor': '#FFFFFF',
                                        'color': '#6B7E8D', 'textAlign': 'center', 'border': '2px solid #6B7E8D'},
                            sort_by=[]),
                    ]),
                html.Div(id='dataframe-vis'),
                html.Div(id='dataframe-vis2'),
            ])

    elif tab == 'tab-2':
        return html.Div(
            id="app-container",
            children=[
                html.H3("Stop & Search Prime Policing Allocation", style={'textAlign': 'center', 'color': '#135DD8',
                                                                          'fontSize': '30', 'fontWeight': 'bold',
                                                                          'margin-top': '3rem'}),
                html.H5('This map shows where the patrolling officers should stand and stop civilians for regular '
                        'searches.',
                        style={'textAlign': 'center', 'color': '#6B7E8D', 'fontSize': '10', 'margin-top': '-2rem',
                               'margin-bottom': '3rem'}),
                html.Div(
                    id="interactive-map",
                    className="interactive-map",
                    children=[
                        html.Iframe(id='map', srcDoc=open('current_map.html').read(), width='100%', height='700')
                    ]),
            ])

    elif tab == 'tab-3':
        return html.Div(
            id="app-container",
            children=[
                # Left column
                html.Div(
                    id="left-column",
                    className="three columns",
                    children=generate_control_tab1()
                ),

                html.Div(
                    id="right-column",
                    className="nine columns",
                    children=[
                        dcc.Graph(id='graph1'),
                        dcc.Graph(id='graph2', figure=fig_sumcrimes),
                        dcc.Graph(id='graph3', figure=fig_crimetype),
                    ])
            ])


@app.callback(
    dash.dependencies.Output('graph1', 'figure'),
    [dash.dependencies.Input(component_id='task1_plot', component_property='value')]
)
def build_fig1(value):
    return plot_seasonality(value)


@app.callback(
    Output('dataframe-vis', "children"),
    Input('dataframe', "derived_virtual_data"),
    Input('dataframe', "derived_virtual_selected_rows"))
def update_graphs(rows, derived_virtual_selected_rows):
    if derived_virtual_selected_rows is None:
        derived_virtual_selected_rows = []

    dff = df if rows is None else pd.DataFrame(rows)
    colors = ['#135DD8' if i in derived_virtual_selected_rows else '#135DD8'
              for i in range(len(dff))]
    return [
        dcc.Graph(
            id=column,
            figure={
                "data": [
                    {
                        "x": dff[column],
                        "y": dff[row],
                        "type": "bar",
                        "marker": {"color": colors},
                    }
                ],
                "layout": {
                    "xaxis": {"automargin": True},
                    "yaxis": {
                        "automargin": True,
                        "title": {"text": 'Amount of Crime'}
                    },
                    "height": 300,
                    "margin": {"t": 10, "l": 10, "r": 10},
                },

            },
        )
        for column in ['Crime type', 'MSOA code'] if column in dff
        for row in ['prediction'] if row in dff
    ]


@app.callback(
    Output('dataframe-vis2', "children"),
    Input('dataframe', "derived_virtual_data"),
    Input('dataframe', "derived_virtual_selected_rows"))
def update_graphs2(rows):
    dff = df if rows is None else pd.DataFrame(rows)

    return px.line(dff, x='Month', y="prediction")
    # if dff['Crime type'].nunique() == 1 and dff['MSOA code'].nunique() == 1:
    # return line_plot(dff)


if __name__ == "__main__":
    app.run_server(debug=False)
