import tqdm as tq
import pandas as pd
import json
import os
import re
from datetime import datetime
import warnings
import os

path_local = os.getcwd()
path_parent = os.path.abspath(os.path.join(path_local, os.pardir))

district = "London"
warnings.filterwarnings(action='ignore')


def extract_street_for_district(district: str):
    directory = path_parent + "/files/Jan_2010_Oct_2021"  # Change directory
    df_street = pd.DataFrame()

    folders = [folder for folder in os.listdir(directory) if not str(folder).strip("'b").startswith('.')]

    for folder in folders:
        files_street = []

        # Here you can change the date range
        if int(folder[:4]) > 2014:
            # generate the path to folder
            folder_direc = os.fsencode(directory + '/' + str(folder))

            # add each file name to the appropriate list
            for file in os.listdir(folder_direc):
                file = str(file).strip("'b")
                # check if the file name contains the appropriate district name and 'street'
                if (bool(re.search(str(district.lower()), file))) & (bool(re.search('street', file))):
                    files_street.append(file)

            # Clean dataframe
            for file in files_street:
                # Create dataframe from the current file
                current_data_street = pd.read_csv(directory + '/' + str(folder).strip("'b") + '/' + str(file))
                # Drop the attributes considered irrelevant
                current_data_street.drop(['Reported by',
                                          'Location', 'Context', 'LSOA name'], axis=1, inplace=True)
                current_data_street.dropna(subset=['LSOA code'], inplace=True)
                current_data_street.dropna(subset=['Crime type'], inplace=True)
                df_street = df_street.append(current_data_street)

    return df_street


## stop-and-search data
def extract_sas_for_district(district: str):
    # To make df_sas and clean the data.

    # Change directory
    directory = path_parent + "/files/Jan_2010_Oct_2021"
    sas = pd.DataFrame()

    folders = [folder for folder in os.listdir(directory) if not str(folder).strip("'b").startswith('.')]

    for folder in folders:
        files_sas = []

        # Here you can change the date range
        if int(folder[:4]) > 2014:
            # generate the path to folder
            folder_direc = os.fsencode(directory + '/' + str(folder))

            # add each file name to the appropriate list
            for file in os.listdir(folder_direc):
                file = str(file).strip("'b")
                # check if the file name contains the appropriate district name and 'street'
                if (bool(re.search(str(district.lower()), file))) & (bool(re.search('stop-and-search', file))):
                    files_sas.append(file)

            # Clean dataframe for stop-and-search
            for file in files_sas:
                # Create dataframe from the current file
                current_data_sas = pd.read_csv(directory + '/' + str(folder).strip("'b") + '/' + str(file))
                # drop the attributes considered irrelevant
                current_data_sas.drop(['Policing operation', 'Gender', 'Object of search',
                                       'Outcome linked to object of search',
                                       'Removal of more than just outer clothing',
                                       'Self-defined ethnicity', 'Officer-defined ethnicity'], axis=1, inplace=True)
                # drop rows which do not have the "Type" specified
                current_data_sas.dropna(subset=['Type'], inplace=True)
                current_data_sas.dropna(subset=['Longitude'], inplace=True)
                current_data_sas.dropna(subset=['Latitude'], inplace=True)
                sas = sas.append(current_data_sas)

    sas['Date'] = pd.to_datetime(sas['Date'])
    sas['Day'] = sas.Date.dt.day
    sas['Month'] = sas.Date.dt.month
    sas['Year'] = sas.Date.dt.year
    sas['total_sec'] = sas.Date.apply(lambda x: datetime.timestamp(x))
    sas['Weekday'] = sas.Date.dt.weekday
    sas['Hour'] = sas.Date.dt.hour
    sas['Minute'] = sas.Date.dt.minute
    sas['Day_of_year'] = sas.Date.dt.dayofyear
    sas['Hour_of_the_week'] = sas.Date.dt.dayofweek * 24 + (sas.Date.dt.hour + 1)
    return sas


df_seasonality = pd.read_csv(path_parent + '/files/graphs_london_gwent.csv')
df_seasonality = df_seasonality[df_seasonality['Police force'].str.contains(district.title())]


def final_predictions(district):
    final_pred = pd.read_csv(path_parent + '/files/final_pred.csv')
    final_pred = final_pred[final_pred['District'].str.contains(district.title())]
    final_pred = final_pred[['Month', 'MSOA code', 'Crime type', 'prediction', 'change', 'max', 'min']]
    return final_pred


df_predictions = final_predictions(district)
