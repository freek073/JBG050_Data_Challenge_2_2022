from DC2_APP.data import *
from sklearn.tree import DecisionTreeRegressor
import datetime

# import data - stop-and-search for the chosen district
sas = extract_sas_for_district(district)
# define the features for prediction
X, y = sas.drop(['Latitude', 'Longitude', 'Age range', 'Date',
                 'Part of a policing operation', 'Type', 'Legislation', 'Outcome'], axis=1), sas[['Longitude', 'Latitude']]

df_future = pd.DataFrame()
x = datetime.datetime(2022, 1, 1, 0)
for i in range(1, 24 * 365):
    x += datetime.timedelta(hours=1)
    df_future.loc[i, 0] = x

df_future = df_future.rename(columns={0: 'Date'})

from datetime import datetime
# feature extraction (time)
df_future['Day'] = df_future.Date.dt.day
df_future['Month'] = df_future.Date.dt.month
df_future['Year'] = df_future.Date.dt.year
df_future['total_sec'] = df_future.Date.apply(lambda x: datetime.timestamp(x))
df_future['Weekday'] = df_future.Date.dt.weekday
df_future['Hour'] = df_future.Date.dt.hour
df_future['Minute'] = df_future.Date.dt.minute
df_future['Day_of_year'] = df_future.Date.dt.dayofyear
df_future['Hour_of_the_week'] = df_future.Date.dt.dayofweek * 24 + (df_future.Date.dt.hour + 1)

df_future = df_future.drop(columns=['Date'])

# define model
dt = DecisionTreeRegressor()
# fit model
dt.fit(X[:1000000], y[:1000000])
# future - prediction
y_pred_future_dt = dt.predict(df_future)

df_future_dt = pd.DataFrame()
df_future_pred_dt = pd.DataFrame(y_pred_future_dt, columns=['Long_pred', 'Lat_pred'])
# df_future['Long_pred'], df_future['Lat_pred'] = yhat
# df_future_dt = df_future.join(df_future_pred_dt)
df_future_dt = df_future.reset_index().join(df_future_pred_dt)